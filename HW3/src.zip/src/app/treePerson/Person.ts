export class Person {
    id!:number;
    personName!: string;
    childAccess!:boolean;
    treePersons!: Person[]|undefined;

    constructor(id:number, personName:string, treePersons?: Person[]){
        this.id= id;
        this.personName = personName;
        this.treePersons = treePersons;
    }
}
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Person } from '../Person';

@Component({
    selector: 'persons',
    templateUrl: './recursive.component.html',
    styleUrls: ['./recursive.component.css']
})

export class PersonsComponent implements OnInit{
    showDiv = false;
    @Input() person!: Person;
    // @Output() selected = new EventEmitter<any>();
    
    onClick(person:Person){
        console.log(person);
        person.childAccess = !person.childAccess;    
    }
    changeName(person:Person){
        let el = document.querySelector('#'+person.personName+'Div');
        el?.classList.toggle('showDiv');
    }
    saveName(person:Person){
        let el = document.querySelector('#'+person.personName+'Div');
        el?.classList.toggle('showDiv');
    }
    deleteElement(person:Person){
        let el = document.querySelector('#'+person.personName+'Main');
        el?.classList.toggle('showElement');    
    }

    // greeting(){
    //     this.selected.emit(this.treePersons);
    // }
    ngOnInit(): void {
    }

}
